const dotenv = require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const cookie = require('cookie');
const nonce = require('nonce')();
const querystring = require('querystring');
const axios = require('axios');
const mongoose=require("mongoose");
const shopifyApiPublicKey = process.env.SHOPIFY_API_KEY;
const shopifyApiSecretKey = process.env.SHOPIFY_API_SECRET;
const scopes = 'write_products';
const appUrl = 'https://16285078f798.ngrok.io';
const MongoClient=require('mongodb').MongoClient;
const app = express();
const PORT = 3000
app.get('/', (req, res) => {
  res.send('Hello')
});
const buildRedirectUri = () => `${appUrl}/shopify/callback`;
const buildInstallUrl = (shop, state, redirectUri) => `https://${shop}/admin/oauth/authorize?client_id=${shopifyApiPublicKey}&scope=${scopes}&state=${state}&redirect_uri=${redirectUri}`;
const buildAccessTokenRequestUrl = (shop) => `https://${shop}/admin/oauth/access_token`;
const buildShopDataRequestUrl = (shop) => `https://${shop}/admin/shop.json`;
const generateEncryptedHash = (params) => crypto.createHmac('sha256', shopifyApiSecretKey).update(params).digest('hex');
const fetchAccessToken = async (shop, data) => await axios(buildAccessTokenRequestUrl(shop), {
  method: 'POST',
  data
});
const fetchShopData = async (shop, accessToken) => await axios(buildShopDataRequestUrl(shop), {
  method: 'GET',
  headers: {
    'X-Shopify-Access-Token': accessToken
  }
});

app.get('/shopify', (req, res) => {
  const shop = req.query.shop;

  if (!shop) { return res.status(400).send('no shop')}

  const state = nonce();

  const installShopUrl = buildInstallUrl(shop, state, buildRedirectUri())

  res.cookie('state', state)
  res.redirect(installShopUrl);
});

app.get('/shopify/callback', async (req, res) => {
  const { shop, code, state } = req.query;
  const stateCookie = cookie.parse(req.headers.cookie).state;
  if (state !== stateCookie) { return res.status(403).send('Cannot be verified')}
  const { hmac, ...params } = req.query
  const queryParams = querystring.stringify(params)
  const hash = generateEncryptedHash(queryParams)
  if (hash !== hmac) { return res.status(400).send('HMAC validation failed')}

  try {
    const data = {
      client_id: shopifyApiPublicKey,
      client_secret: shopifyApiSecretKey,
      code
    };
    const tokenResponse = await fetchAccessToken(shop, data)

    const { access_token } = tokenResponse.data
    MongoClient.connect(process.env.MONGODB,function (err,db){
        if (err) throw err;
        var dbo = db.db("shop")
        dbo.collection("access").deleteMany({AccessToken:/^s/},function(err,res){
            if (err) throw err;
        });
        dbo.collection("access").insertOne({
            AccessToken:access_token
        },function(err,res){
            if (err) throw err;
            console.log("Values Inserted");
            db.close();
        })
    })
        
    console.log(access_token);
   
    const shopData = await fetchShopData(shop, access_token)
    res.send(shopData.data.shop)

  } catch(err) {
    console.log(err)
    res.status(500).send('something went wrong')
  }
});


app.listen(PORT, () => console.log(`listening on port ${PORT}`));